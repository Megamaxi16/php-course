---
title: Box2
categories:
  - Real World
tags:
  - cardboard
  - package
  - cube
---
