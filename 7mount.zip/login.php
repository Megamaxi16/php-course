<?php
    session_start();
    $csrf_token = bin2hex(random_bytes(32)); // Gera um token CSRF aleatório
    $_SESSION['csrf_token'] = $csrf_token; // Armazena o token na sessão
?>
<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8" />
    <title>Login - 7Mount</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0, shrink-to-fit=no, user-scalable=no">
    <meta name="description" content="Sistema de Secretária 7Mount"/>
    <meta name="author" content="RDORVAL SOLUÇÕES EM TECNOLOGIA" />
    <meta name="analist" content="CARLOS ALEXANDRE">
    <meta name="mobile-web-app-capable" content="yes">
    <meta name="apple-mobile-web-app-capable" content="yes">
    <meta name="application-name" content="App 7Mount">
    <meta name="apple-mobile-web-app-title" content="App 7Mount">
    <meta name="theme-color" content="#556ee6">
    <meta name="msapplication-navbutton-color" content="#556ee6">
    <meta name="apple-mobile-web-app-status-bar-style" content="default">
    <meta name="msapplication-starturl" content="/7mount/login.php">

    <!-- App favicon -->
    <link rel="shortcut icon" href="assets/images/favicon.ico">

    <!-- Css -->
    <link href="assets/libs/sweetalert2/sweetalert2.min.css" rel="stylesheet" type="text/css" />
    <link rel="stylesheet" href="assets/libs/owl.carousel/assets/owl.carousel.min.css">
    <link rel="stylesheet" href="assets/libs/owl.carousel/assets/owl.theme.default.min.css">
    <link href="assets/css/bootstrap.min.css" id="bootstrap-style" rel="stylesheet" type="text/css" />
    <link href="assets/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="assets/css/app.min.css" id="app-style" rel="stylesheet" type="text/css" />
    <!-- End Css -->

</head>

<body class="auth-body-bg">

<div>
    <div class="container-fluid p-0">
        <div class="row g-0">

            <div class="col-xl-8">
                <div class="auth-full-bg pt-lg-5 p-4">
                    <div class="w-100">
                        <div class="bg-overlay"></div>
                        <div class="d-flex h-100 flex-column">

                            <div class="p-4 mt-auto">
                                <div class="row justify-content-center">
                                    <div class="col-lg-7">

                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end col -->

            <div class="col-xl-4">
                <div class="auth-full-page-content p-md-5 p-4">
                    <div class="w-100">

                        <div class="d-flex flex-column h-100">
                            <div class="mb-4 mb-md-5">
                                <a href="login.php" class="d-block auth-logo">
                                    <img src="assets/images/logo-dark.png" alt="" height="80" class="auth-logo-dark">
                                    <img src="assets/images/logo-light.png" alt="" height="80" class="auth-logo-light">
                                </a>
                            </div>
                            <div class="my-auto">
                                <div>
                                    <h5 class="text-primary">Seja Bem-vindo!</h5>
                                    <p class="text-muted">Inicie sessão na sua conta</p>
                                </div>
                                <div class="mt-4">
                                    <form name="login-form" id="login-form" action="" method="POST">
                                        <input type="hidden" name="csrf_token" id="csrf_token" value="<?php echo $csrf_token; ?>">
                                        <div class="mb-3">
                                            <label for="username" class="form-label">Usuário</label>
                                            <input type="text" class="form-control" name="login-email" id="login-email" placeholder="Digite seu usuário">
                                        </div>

                                        <div class="mb-3">
                                            <div class="float-end">
                                                <a href="auth-recover.php?vr=true" class="text-muted">Esqueceu a senha?</a>
                                            </div>
                                            <label class="form-label">Senha</label>
                                            <div class="input-group auth-pass-inputgroup">
                                                <input type="password" class="form-control" name="login-password" id="login-password" placeholder="Digite sua Senha" aria-label="Password" aria-describedby="password-addon">
                                                <button type="button" class="btn btn-light" id="password-addon"><i class="mdi mdi-eye-outline"></i></button>
                                            </div>
                                        </div>

                                        <div class="mt-3 d-grid">
                                            <button type="submit" class="btn btn-primary waves-effect waves-light" id="btn-login">Conectar</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                            <div class="mt-4 mt-md-5 text-center">
                                <p class="mb-0">© <script>document.write(new Date().getFullYear())</script> - 7Mount. Desenvolvido por RDorval</p>
                                <p>Versão 1.0.0</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- end col -->
        </div>
        <!-- end row -->
    </div>
    <!-- end container-fluid -->
</div>

<!-- JAVASCRIPT -->
<script src="assets/libs/jquery/jquery.min.js"></script>
<script src="assets/libs/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="assets/libs/metismenu/metisMenu.min.js"></script>
<script src="assets/libs/simplebar/simplebar.min.js"></script>
<script src="assets/libs/node-waves/waves.min.js"></script>
<script src="assets/js/pages/auth/auth.js?v=<?php echo time(); ?>"></script>
<!-- owl.carousel js -->
<script src="assets/libs/owl.carousel/owl.carousel.min.js"></script>
<!-- auth-2-carousel init -->
<script src="assets/js/pages/auth-2-carousel.init.js"></script>
<!-- Sweet Alerts js -->
<script src="assets/libs/sweetalert2/sweetalert2.min.js"></script>


<!-- App js -->
<script src="assets/js/app.js"></script>

</body>
</html>
