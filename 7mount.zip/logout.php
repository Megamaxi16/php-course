<?php
use functions\Logs;

require_once (__DIR__.'/connections/conecta_db.php');
require_once (__DIR__.'/functions/Logs.php');

# Instancia a conexão
$conn = Database::conexao();

# Instancia o gravaLogs
$logs = new Logs();

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

$logs->gravaLog($conn, $_SERVER['HTTP_REFERER'], 'Logout', 'Desconectou-se do sistema');

session_unset();
session_destroy();

# Fecha a conexão
$conn->close();

header("Location: login.php");
exit(); // Encerra o script após o redirecionamento
